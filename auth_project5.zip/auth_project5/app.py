from flask import Flask,request,render_template,redirect,session,flash
from flask_login import login_user, logout_user, login_required, current_user, LoginManager, UserMixin
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import func
from sqlalchemy.exc import IntegrityError
from flask_mail import Mail, Message
from flask_migrate import Migrate
from flask import url_for
import bcrypt
import secrets
import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)
app.secret_key = 'secret_key'
app.static_url_path = '/static'

#instance for SMTP Server
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Gmail SMTP server
app.config['MAIL_PORT'] = 587 # Port for TLS
app.config['MAIL_USE_TLS'] = True  # Use TLS (True for Gmail)
app.config['MAIL_USE_SSL'] = False # Do not use SSL
app.config['MAIL_USERNAME'] = 'prototype.test8080@gmail.com'
app.config['MAIL_PASSWORD'] = 'jcxk kofh hjcb dqmy'


login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.init_app(app)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

mail = Mail(app)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    account_status = db.Column(db.String(100))
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())


    def __init__(self,email,password,username,account_status):
        self.username = username
        self.email = email
        self.password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        self.account_status = account_status
    
    def check_password(self,password):
        return bcrypt.checkpw(password.encode('utf-8'),self.password.encode('utf-8'))

class ResetTokenModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(128), unique=True, nullable=False)
    expiration_time = db.Column(db.DateTime, nullable=False)

def generate_unique_token():
    return secrets.token_urlsafe(32)

def verify_reset_token(token):
    # Query the database for the reset token
    reset_token = ResetTokenModel.query.filter_by(token=token).first()

    if reset_token:
        # Check if the token has not expired
        if reset_token.expiration_time > datetime.datetime.now():
            return True
    return False 


# Initialize the login attempts session variable
def initialize_login_attempts():
    if 'login_attempts' not in session:
        session['login_attempts'] = 0
        session['last_failed_login'] = 0

with app.app_context():
    db.create_all()

# using sha256 to hide url routes
signup_hash='/7c8718bdc78be44bf7f3e5554152c20e99216dcb93ac9aefb8857fd7f9d02102'
home_hash = '/e83249bd3ba79932e16fb1fb5100dafade9954c2'
login_hash = '/2736fab291f04e69b62d490c3c09361f5b82461a'
forgot_password_hash = '/9e3183adc4eebf3adb598d35aa507d9d6f503070'
reset_password_hash = '/868a882a74b3f7f4cc49d8914e144ef07b3ea9d5'
logout_hash = '/55525e1b3dfd8787fd202aed45fb04494e3242d0'


@app.route(signup_hash,methods=['GET','POST'])
def register():
    if request.method == 'POST':
        # handle request
        username = request.form['username']
        email = request.form['email']
        password1 = request.form['password1']
        password2 = request.form['password2']
        account_status = "active"
        specialChars = ['~', ':', "'", '+', '[', '\\', '@', '^', '{', '%', '(', '-', '"', '*', '|', ',', '&', '<', '`', '}', '.', '_', '=', ']', '!', '>', ';', '?', '#', '$', ')', '/']
        emailChars = ['@','.']
        

        # Check if the email already exists in the database
        existing_user = User.query.filter_by(email=email).first()
        username_exists = User.query.filter_by(username=username).first()
        checkSpecialPass = [char for char in specialChars if(char in password1)]
        checkEmailEntry = [char for char in emailChars if(char in email)]
        
        # smart check of email
        if not username or not email or not password1:
            flash('Please fill in all fields.','error')
        elif not checkEmailEntry or len(email) < 4:
            flash('The email you entered is not valid.', category='error')
        elif existing_user:
            flash('Email already exists. Please use a different email instead.','error')
        elif username_exists:
            flash('Username is already in use.', category='error')
        
        # smart check of username length
        elif len(username) < 2:
            flash('Username is too short.', category='error')
            
        # smart check of password length and match
        elif password1 != password2:
            flash('Passwords you entered doesn\'t match.', category='error')
        elif len(password1) <= 8:
            flash('Password is too short. It must contain at least 8 characters long.', category='error')
            
        # smart check of password entry
        elif password1.isalpha():
            flash("Password you entered only consists of alphabets. It must be in a combination of alphanumeric numbers and special characters (!,@,#,$,%,^,&,*,etc.).", category='error')
        elif password1.isdigit():
            flash("Password you entered only consists of numbers. It must be in a combination of alphanumeric numbers and special characters (!,@,#,$,%,^,&,*,etc.).", category='error')
        elif password1.islower():
            flash("Password you entered only consists of lowercase alphabet characters. Include uppercase alphabet characters as well.", category='error')
        elif password1.isupper():
            flash("Password you entered only consists of uppercase alphabet characters. Include lowercase alphabet characters as well.", category='error')
        elif not checkSpecialPass:
            flash('Password you entered does not contain any special character (!,@,#,$,%,^,&,*,etc.).', category='error')
        else:
            new_user = User(username=username, email=email, password=password1, account_status=account_status)
            db.session.add(new_user)
            try:
                db.session.commit()
                flash('Account created successfully. You can now log in.', 'success')
                session['logged_in'] = True
                login_user(new_user, remember=True)
                return redirect(home_hash)
            except IntegrityError:
                db.session.rollback()
                #return render_template('signup.html', error='An error occurred while creating your account. Please try again.')
                flash('An error occurred while creating your account. Please try again.','error')

    return render_template('signup.html')

# Log In page
@app.route('/')
def index():
    return render_template('index.html',signup_hash=signup_hash)


@app.route(login_hash, methods=['GET', 'POST'])
def login():
    initialize_login_attempts()  # Initialize login attempts here
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()
        
        if user.account_status == "active":
            if user and user.check_password(password):
                session['email'] = user.email
                session['login_attempts'] = 0  # Reset login attempts on successful login
                session['logged_in'] = True
                login_user(user, remember=True)
                return render_template('home.html', username=user.username)
            elif user is None:
                #return render_template('login.html', error='User not found. Please <a href="/register" class="register-link">register</a>.')
                flash('User not found!','error')
            else:
                session['login_attempts'] += 1  # Increment login attempts
                if session['login_attempts'] >= 3:
                    user.account_status = "disabled"
                    db.session.commit()
                    session['login_attempts'] = 0
                    # Generate a unique reset token
                    reset_token = generate_unique_token()
                    # Set the expiration time (e.g., 24 hours from now)
                    expiration_time = datetime.datetime.now() + datetime.timedelta(hours=24)
                    # Create a ResetTokenModel object and store it in the database
                    reset_token_obj = ResetTokenModel(token=reset_token, expiration_time=expiration_time)
                    db.session.add(reset_token_obj)
                    db.session.commit()
                    # Send an email to the user with a link to reset their password
                    reset_link = url_for('reset_password', token=reset_token, _external=True)
                    msg = Message('<TEAM NAME>| Your account is disabled.', sender='prototype.test8080@gmail.com', recipients=[user.email])
                    msg.html = render_template('locked_email.html', reset_link=reset_link, username=user.username)
                    mail.send(msg)
                    return render_template('locked.html')
                flash("Invalid Username or Password.",'error')
            return render_template('login.html', error='Invalid Username or Password.')
        else: 
            flash("The account you're login is currently disabled, click forget password to reset.",'error')
    return render_template('login.html')

# Forgot password
@app.route(forgot_password_hash, methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email'].strip()  # Remove leading/trailing whitespace
        session['email'] = email

        if not email:
            return render_template('forgot_password.html', error='Please enter your email address.')
    
        # Check if the email exists in the database
        user = User.query.filter_by(email=email).first()
        if user:
            # Generate a unique reset token
            reset_token = generate_unique_token()
            # Set the expiration time (e.g., 24 hours from now)
            expiration_time = datetime.datetime.now() + datetime.timedelta(hours=24)
            # Create a ResetTokenModel object and store it in the database
            reset_token_obj = ResetTokenModel(token=reset_token, expiration_time=expiration_time)
            db.session.add(reset_token_obj)
            db.session.commit()
            # Send an email to the user with a link to reset their password
            reset_link = url_for('reset_password', token=reset_token, _external=True)
            msg = Message('<TEAM NAME>| Password Reset', sender='prototype.test8080@gmail.com', recipients=[user.email])
            msg.html = render_template('reset_email.html', reset_link=reset_link, username=user.username)
            mail.send(msg)
            return render_template('email_sent.html')
        else:
            flash('The email you input hasn\'t been registered yet. Try to sign up instead.','error')
            return redirect(forgot_password_hash)
    return render_template('forgot_password.html')

# Reset password
@app.route('/868a882a74b3f7f4cc49d8914e144ef07b3ea9d5/<token>', methods=['GET', 'POST'])
def reset_password(token):
    specialChars = ['~', ':', "'", '+', '[', '\\', '@', '^', '{', '%', '(', '-', '"', '*', '|', ',', '&', '<', '`', '}', '.', '_', '=', ']', '!', '>', ';', '?', '#', '$', ')', '/']
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        # Verify the reset token
        checkSpecialPass = [char for char in specialChars if(char in new_password)]
        if not verify_reset_token(token):
            flash('Invalid or expired reset token.','error')
        elif new_password != confirm_password:
            flash('Passwords do not match.','error')
        elif len(new_password) <= 8:
            flash('Password is too short. It must contain at least 8 characters long.', category='error')
        # smart check of password entry
        elif new_password.isalpha():
            flash("Password you entered only consists of alphabets. It must be in a combination of alphanumeric numbers and special characters (!,@,#,$,%,^,&,*,etc.).", category='error')
        elif new_password.isdigit():
            flash("Password you entered only consists of numbers. It must be in a combination of alphanumeric numbers and special characters (!,@,#,$,%,^,&,*,etc.).", category='error')
        elif new_password.islower():
            flash("Password you entered only consists of lowercase alphabet characters. Include uppercase alphabet characters as well.", category='error')
        elif new_password.isupper():
            flash("Password you entered only consists of uppercase alphabet characters. Include lowercase alphabet characters as well.", category='error')
        elif not checkSpecialPass:
            flash('Password you entered does not contain any special character (!,@,#,$,%,^,&,*,etc.).', category='error')
        else:
            user = User.query.filter_by(email=session['email']).first()  # Retrieve the user based on their email or any other identifier
            user.account_status = "active"
            db.session.commit()
            if user:
                user.password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
                db.session.commit()  # Commit the changes to the database
                flash('Account password updated.','success')
                return redirect(login_hash)
            
            
    return render_template('reset_password.html', token=token)






@app.route(logout_hash)
@login_required
def logout():
    session.pop('email',None)
    session['logged_in'] = False
    logout_user()
    return redirect(login_hash)

#loged_main page
@login_required
@app.route(home_hash)
def home():
    try:
        return render_template('home.html',name=current_user.username)
    except:
        flash('Please login first.','error')
        return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)